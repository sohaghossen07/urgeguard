package com.urge.guard
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class GuardService : AccessibilityService() {
    private val allowed = setOf("com.android.phone", "com.android.incallui",
        "com.google.android.dialer", "com.android.dialer", "com.samsung.android.incallui")
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val p = e?.packageName?.toString() ?: return
        if (!MainActivity.isLocked(this)) return
        if (p == packageName || p in allowed) return
        startActivity(Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }
    override fun onInterrupt() {}
}
