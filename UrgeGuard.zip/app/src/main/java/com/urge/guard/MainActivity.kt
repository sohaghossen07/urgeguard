package com.urge.guard
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*

class MainActivity : Activity() {
    companion object {
        fun end(c: Context) = c.getSharedPreferences("g", 0).getLong("end", 0L)
        fun isLocked(c: Context) = System.currentTimeMillis() < end(c)
    }
    private val h = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private val tick = object : Runnable { override fun run() { render(); h.postDelayed(this, 1000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#111827")); setPadding(48, 48, 48, 48)
        }
        setContentView(root)
    }
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
    @Deprecated("") override fun onBackPressed() { if (!isLocked(this)) super.onBackPressed() }

    private fun tv(t: String, sz: Float, col: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(col); gravity = Gravity.CENTER; setPadding(0, 16, 0, 16)
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    private fun accOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }
    private fun adminOn() = (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager)
        .isAdminActive(ComponentName(this, AdminReceiver::class.java))

    private fun start(min: Int) {
        getSharedPreferences("g", 0).edit().putLong("end", System.currentTimeMillis() + min * 60000L).apply()
        render()
    }

    private fun render() {
        root.removeAllViews()
        val locked = isLocked(this)
        val w = window
        if (locked) {
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            @Suppress("DEPRECATION") root.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            val left = (end(this) - System.currentTimeMillis()) / 1000
            root.addView(tv("%02d:%02d".format(left / 60, left % 60), 64f))
            root.addView(tv("ইচ্ছা ঢেউয়ের মতো, নিজে থেকেই কমে যাবে।\nধীরে শ্বাস নিন (৪ সেকেন্ড), ছাড়ুন (৬ সেকেন্ড)।\nঘর থেকে বের হন বা হাঁটুন।", 18f, Color.LTGRAY))
        } else {
            w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            @Suppress("DEPRECATION") root.systemUiVisibility = 0
            root.addView(tv("Urge Guard", 28f))
            if (!accOn()) {
                root.addView(tv("ধাপ ১: Accessibility চালু করুন", 16f, Color.YELLOW))
                root.addView(btn("Accessibility Settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
            }
            if (!adminOn()) {
                root.addView(tv("ধাপ ২: Device Admin চালু করুন", 16f, Color.YELLOW))
                root.addView(btn("Device Admin চালু") {
                    startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java)))
                })
            }
            if (accOn() && adminOn()) {
                root.addView(tv("ইচ্ছা হলে বাটন চাপুন। টাইমার শেষ না হওয়া পর্যন্ত সব লক থাকবে।", 16f, Color.LTGRAY))
                root.addView(btn("৫ মিনিট লক") { start(5) })
                root.addView(btn("১০ মিনিট লক") { start(10) })
                root.addView(btn("১৫ মিনিট লক") { start(15) })
            }
        }
    }
}
