package com.urge.guard
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*

class BreathView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#38BDF8") }
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0F172A"); textSize = 56f; textAlign = Paint.Align.CENTER
    }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(640, 640) }
    override fun onDraw(cv: Canvas) {
        val ms = (System.currentTimeMillis() % 10000).toInt()
        val inhale = ms < 4000
        val f = if (inhale) ms / 4000f else 1f - (ms - 4000) / 6000f
        cv.drawCircle(width / 2f, height / 2f, 100f + 210f * f, p)
        cv.drawText(if (inhale) "নিন" else "ছাড়ুন", width / 2f, height / 2f + 20f, t)
        postInvalidateOnAnimation()
    }
}

class Ph(val from: Int, val to: Int, val title: String, val text: String)

class MainActivity : Activity() {
    companion object {
        fun end(c: Context) = c.getSharedPreferences("g", 0).getLong("end", 0L)
        fun isLocked(c: Context) = System.currentTimeMillis() < end(c)
        val BREATH = "বৃত্ত বড় হলে ৪ সেকেন্ড শ্বাস নিন, ছোট হলে ৬ সেকেন্ড ধরে ধীরে ছাড়ুন।"
        val EX = "মেঝেতে দাঁড়িয়ে পুশ-আপ, স্কোয়াট বা লাফানো করুন। ক্লান্ত হওয়াই লক্ষ্য।"
        val RELAX = "পায়ের পাতা থেকে মাথা পর্যন্ত এক এক অংশ ৫ সেকেন্ড শক্ত করুন, তারপর ছেড়ে দিন।"
        val MATH = "মনে মনে ১০০ থেকে ৭ করে বিয়োগ করুন: ১০০, ৯৩, ৮৬, ৭৯... ভুল হলে আবার শুরু।"
        val GROUND = "৫টা জিনিস দেখুন, ৪টা ছুঁয়ে দেখুন, ৩টা শব্দ শুনুন, ২টা গন্ধ নিন, ১টা স্বাদ নিন।"
        val SURF = "চোখ বন্ধ করুন। ইচ্ছাটা শরীরের কোথায় আছে দেখুন। ভাবুন: এটা একটা ঢেউ, আসছে, আবার চলে যাবে। লড়বেন না, শুধু দেখুন।"
        fun phases(total: Int): List<Ph> = when (total) {
            300 -> listOf(Ph(0, 60, "ধীর শ্বাস", BREATH), Ph(60, 180, "শরীর নাড়ান", EX), Ph(180, 300, "৫-৪-৩-২-১", GROUND))
            900 -> listOf(Ph(0, 120, "ধীর শ্বাস", BREATH), Ph(120, 360, "শরীর নাড়ান", EX),
                Ph(360, 540, "পেশি শিথিল", RELAX), Ph(540, 720, "Urge Surfing", SURF), Ph(720, 900, "মাথার কাজ", MATH))
            else -> listOf(Ph(0, 120, "ধীর শ্বাস", BREATH), Ph(120, 300, "শরীর নাড়ান", EX),
                Ph(300, 480, "পেশি শিথিল", RELAX), Ph(480, 600, "মাথার কাজ", MATH))
        }
    }
    private val h = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private var sig = ""
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private var lastTitle = ""
    private var lastInhale: Boolean? = null
    private val breathLoop = object : Runnable {
        override fun run() {
            if (isLocked(this@MainActivity) && titleTv?.text == "ধীর শ্বাস") {
                val inh = (System.currentTimeMillis() % 10000) < 4000
                if (lastInhale != inh) {
                    lastInhale = inh
                    if (ttsOk && tts?.isSpeaking != true) say(if (inh) "নিন" else "ছাড়ুন", false)
                }
            }
            h.postDelayed(this, 200)
        }
    }
    private fun say(t: String, flush: Boolean) {
        if (ttsOk) tts?.speak(t, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "u")
    }
    private fun buzz() {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") v.vibrate(300)
        } catch (e: Exception) {}
    }
    private var timerTv: TextView? = null
    private var titleTv: TextView? = null
    private var textTv: TextView? = null
    private val tick = object : Runnable { override fun run() { render(); h.postDelayed(this, 1000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#111827")); setPadding(48, 48, 48, 48)
        }
        setContentView(root)
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                var r = tts?.setLanguage(Locale("bn", "BD")) ?: -2
                if (r < 0) r = tts?.setLanguage(Locale("bn", "IN")) ?: -2
                ttsOk = r >= 0
                tts?.setSpeechRate(0.95f)
            }
        }
    }
    override fun onResume() { super.onResume(); sig = ""; h.post(tick); h.post(breathLoop) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick); h.removeCallbacks(breathLoop); tts?.stop() }
    override fun onDestroy() { super.onDestroy(); tts?.shutdown() }
    @Deprecated("") override fun onBackPressed() { if (!isLocked(this)) super.onBackPressed() }

    private fun tv(t: String, sz: Float, col: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(col); gravity = Gravity.CENTER; setPadding(0, 12, 0, 12)
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    private fun accOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }
    private fun adminOn() = (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager)
        .isAdminActive(ComponentName(this, AdminReceiver::class.java))

    private fun start(min: Int) {
        getSharedPreferences("g", 0).edit()
            .putLong("end", System.currentTimeMillis() + min * 60000L).putInt("total", min * 60).apply()
        render()
    }

    private fun render() {
        if (isLocked(this)) {
            if (sig != "L") buildLock()
            updateLock()
        } else {
            if (lastTitle != "") { lastTitle = ""; buzz(); say("সময় শেষ। আপনি পেরেছেন!", true) }
            val s = "S${accOn()}${adminOn()}"
            if (s != sig) { sig = s; buildSetup() }
        }
    }

    private fun buildLock() {
        sig = "L"
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION") root.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        root.removeAllViews()
        timerTv = tv("", 44f); titleTv = tv("", 24f, Color.parseColor("#38BDF8")); textTv = tv("", 17f, Color.LTGRAY)
        root.addView(timerTv); root.addView(BreathView(this)); root.addView(titleTv); root.addView(textTv)
    }

    private fun updateLock() {
        val left = ((end(this) - System.currentTimeMillis()) / 1000).toInt()
        val total = getSharedPreferences("g", 0).getInt("total", 600)
        val el = (total - left).coerceAtLeast(0)
        timerTv?.text = "%02d:%02d".format(left / 60, left % 60)
        val ph = phases(total).firstOrNull { el >= it.from && el < it.to } ?: phases(total).last()
        titleTv?.text = ph.title; textTv?.text = ph.text
        if (ph.title != lastTitle) { lastTitle = ph.title; buzz(); say(ph.title + "। " + ph.text, true) }
    }

    private fun buildSetup() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION") root.systemUiVisibility = 0
        root.removeAllViews()
        root.addView(tv("Urge Guard", 28f))
        if (!accOn()) {
            root.addView(tv("ধাপ ১: Accessibility চালু করুন", 16f, Color.YELLOW))
            root.addView(btn("Accessibility Settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        }
        if (!adminOn()) {
            root.addView(tv("ধাপ ২: Device Admin চালু করুন", 16f, Color.YELLOW))
            root.addView(btn("Device Admin চালু") {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java)))
            })
        }
        if (accOn() && adminOn()) {
            root.addView(tv("ইচ্ছা হলে বাটন চাপুন। টাইমার শেষ না হওয়া পর্যন্ত সব লক থাকবে।", 16f, Color.LTGRAY))
            root.addView(btn("৫ মিনিট লক") { start(5) })
            root.addView(btn("১০ মিনিট লক") { start(10) })
            root.addView(btn("১৫ মিনিট লক") { start(15) })
        }
    }
}
