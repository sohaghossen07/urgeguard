package com.urge.guard
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class OrbView(c: Context) : View(c) {
    var kind = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0F172A"); textSize = 56f; textAlign = Paint.Align.CENTER
    }
    private val cols = intArrayOf(Color.parseColor("#38BDF8"), Color.parseColor("#FB923C"),
        Color.parseColor("#A78BFA"), Color.parseColor("#34D399"), Color.parseColor("#FACC15"), Color.parseColor("#60A5FA"))
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(700, 700) }
    private fun al(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    private fun dk(c: Int) = Color.rgb((Color.red(c) * 0.3).toInt(), (Color.green(c) * 0.3).toInt(), (Color.blue(c) * 0.3).toInt())
    private fun dots(cv: Canvas, cx: Float, cy: Float, r: Float, t: Long, front: Boolean, col: Int) {
        for (i in 0..2) {
            val a = t / 2500.0 * 2 * PI + i * 2 * PI / 3
            val d = sin(a).toFloat()
            if ((d >= 0) != front) continue
            val x = cx + (r + 70f) * cos(a).toFloat()
            val y = cy + 0.3f * (r + 70f) * d
            val s = 14f + 8f * d
            p.shader = RadialGradient(x - s / 3, y - s / 3, s * 1.4f, intArrayOf(Color.WHITE, col), null, Shader.TileMode.CLAMP)
            cv.drawCircle(x, y, s, p)
        }
    }
    override fun onDraw(cv: Canvas) {
        val t = System.currentTimeMillis()
        val col = cols[kind.coerceIn(0, 5)]
        val cx = width / 2f; val cy = height / 2f - 30f
        var inhale = true
        val r: Float
        if (kind == 0) {
            val ms = (t % 10000).toInt(); inhale = ms < 4000
            val f = if (inhale) ms / 4000f else 1f - (ms - 4000) / 6000f
            r = 90f + 150f * f
        } else r = 160f + 14f * sin(t / 700.0).toFloat()
        p.shader = null; p.color = Color.argb(70, 0, 0, 0)
        cv.drawOval(RectF(cx - r * 0.8f, cy + r + 40f, cx + r * 0.8f, cy + r + 40f + r * 0.18f), p)
        p.shader = RadialGradient(cx, cy, r * 1.5f, intArrayOf(al(col, 110), al(col, 0)), null, Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r * 1.5f, p)
        dots(cv, cx, cy, r, t, false, col)
        p.shader = RadialGradient(cx - r * 0.35f, cy - r * 0.4f, r * 1.4f,
            intArrayOf(Color.WHITE, col, dk(col)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r, p)
        if (kind == 0) cv.drawText(if (inhale) "নিন" else "ছাড়ুন", cx, cy + 20f, tp)
        dots(cv, cx, cy, r, t, true, col)
        postInvalidateOnAnimation()
    }
}

class Ph(val kind: Int, val title: String, val from: Int, val to: Int, val lines: List<String>)

class MainActivity : Activity() {
    companion object {
        fun end(c: Context) = c.getSharedPreferences("g", 0).getLong("end", 0L)
        fun isLocked(c: Context) = System.currentTimeMillis() < end(c)
        val BR = listOf("সোজা হয়ে বসুন, কাঁধ ঢিলা করুন।", "নাক দিয়ে ধীরে শ্বাস নিন, পেট ফুলতে দিন।",
            "মুখ দিয়ে লম্বা করে ছাড়ুন, ছাড়াটা নেওয়ার চেয়ে লম্বা হোক।", "ভালো হচ্ছে। ইচ্ছা একটা ঢেউ, আসছে আবার চলে যাবে।",
            "প্রতিবার ছাড়ার সময় শরীর আরও ঢিলা করুন।", "আপনি ঠিক পথে আছেন, চালিয়ে যান।")
        val MV = listOf("দাঁড়ান। ১৫টা স্কোয়াট করুন, ধীরে নামুন, ধীরে উঠুন।", "বিশ্রাম নিন, শ্বাস স্বাভাবিক করুন।",
            "১৫টা পুশ-আপ করুন, না পারলে দেয়ালে ভর দিয়ে।", "বিশ্রাম নিন, কাঁধ ঢিলা রাখুন।",
            "জায়গায় দৌড়ান, হাঁটু উঁচু করে।", "বিশ্রাম নিন, ধীরে শ্বাস নিন।")
        val RX = listOf("দুই পায়ের পাতা শক্ত করুন... এবার ছেড়ে দিন।", "উরু ও পায়ের পেশি শক্ত করুন... ছেড়ে দিন।",
            "পেট ও কোমর শক্ত করুন... ছেড়ে দিন।", "দুই হাতের মুঠো শক্ত করুন... ছেড়ে দিন।",
            "কাঁধ কানের দিকে তুলুন... ছেড়ে দিন।", "মুখ ও চোখ শক্ত করুন... ছেড়ে দিন।")
        val MA = listOf("মনে মনে ১০০ থেকে ৭ করে বিয়োগ করুন: ১০০, ৯৩, ৮৬।", "৭৯, ৭২, ৬৫... চালিয়ে যান।",
            "৫৮, ৫১, ৪৪... ভুল হলে আবার ১০০ থেকে।", "৩৭, ৩০, ২৩... মনোযোগ শুধু সংখ্যায়।",
            "১৬, ৯, ২... এবার আবার ১০০ থেকে।", "চমৎকার, মাথা এখন অন্য কাজে ব্যস্ত।")
        val GR = listOf("চারপাশে তাকিয়ে ৫টা জিনিস দেখুন, মনে মনে নাম বলুন।", "৪টা জিনিস ছুঁয়ে দেখুন, কেমন লাগে খেয়াল করুন।",
            "চুপ করে ৩টা শব্দ শুনুন।", "২টা গন্ধ নেওয়ার চেষ্টা করুন।", "১টা স্বাদ খেয়াল করুন।", "ধীরে শ্বাস নিন। আপনি পেরেছেন।")
        val SF = listOf("চোখ বন্ধ করুন। ইচ্ছাটা শরীরের কোথায় আছে দেখুন।", "ওটা কেমন, গরম, টান, নাকি ভারী? শুধু খেয়াল করুন।",
            "ভাবুন এটা একটা ঢেউ, উঠছে।", "লড়বেন না, ঢেউয়ের ওপর ভেসে থাকুন।",
            "দেখুন ঢেউটা চূড়া ছুঁয়ে নামতে শুরু করেছে।", "ইচ্ছা কমছে। আপনি এটা সামলাচ্ছেন।")
        fun phases(total: Int): List<Ph> = when (total) {
            300 -> listOf(Ph(0, "ধীর শ্বাস", 0, 60, BR), Ph(1, "শরীর নাড়ান", 60, 180, MV), Ph(4, "৫-৪-৩-২-১", 180, 300, GR))
            900 -> listOf(Ph(0, "ধীর শ্বাস", 0, 120, BR), Ph(1, "শরীর নাড়ান", 120, 360, MV), Ph(2, "পেশি শিথিল", 360, 540, RX),
                Ph(5, "Urge Surfing", 540, 720, SF), Ph(3, "মাথার কাজ", 720, 840, MA), Ph(0, "শেষ শ্বাস", 840, 900, BR))
            else -> listOf(Ph(0, "ধীর শ্বাস", 0, 120, BR), Ph(1, "শরীর নাড়ান", 120, 300, MV),
                Ph(2, "পেশি শিথিল", 300, 480, RX), Ph(3, "মাথার কাজ", 480, 600, MA))
        }
    }
    private val h = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private var sig = ""
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private var lastKey = ""
    private var lastInhale: Boolean? = null
    private var curKind = -1
    private var timerTv: TextView? = null
    private var titleTv: TextView? = null
    private var stepTv: TextView? = null
    private var textTv: TextView? = null
    private var orb: OrbView? = null
    private var pb: ProgressBar? = null
    private val tick = object : Runnable { override fun run() { render(); h.postDelayed(this, 1000) } }
    private val breathLoop = object : Runnable {
        override fun run() {
            if (isLocked(this@MainActivity) && curKind == 0) {
                val inh = (System.currentTimeMillis() % 10000) < 4000
                if (lastInhale != inh) {
                    lastInhale = inh
                    if (ttsOk && tts?.isSpeaking != true) say(if (inh) "নিন" else "ছাড়ুন", false)
                }
            }
            h.postDelayed(this, 200)
        }
    }
    private fun say(t: String, flush: Boolean) {
        if (ttsOk) tts?.speak(t, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "u")
    }
    private fun buzz() {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") v.vibrate(300)
        } catch (e: Exception) {}
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0B1220")); setPadding(40, 40, 40, 40)
        }
        setContentView(root)
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                var r = tts?.setLanguage(Locale("bn", "BD")) ?: -2
                if (r < 0) r = tts?.setLanguage(Locale("bn", "IN")) ?: -2
                ttsOk = r >= 0
                tts?.setSpeechRate(0.95f)
            }
        }
    }
    override fun onResume() { super.onResume(); sig = ""; h.post(tick); h.post(breathLoop) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick); h.removeCallbacks(breathLoop); tts?.stop() }
    override fun onDestroy() { super.onDestroy(); tts?.shutdown() }
    @Deprecated("") override fun onBackPressed() { if (!isLocked(this)) super.onBackPressed() }

    private fun tv(t: String, sz: Float, col: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(col); gravity = Gravity.CENTER; setPadding(0, 10, 0, 10)
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun accOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains("$packageName/")
    }
    private fun adminOn() = (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager)
        .isAdminActive(ComponentName(this, AdminReceiver::class.java))

    private fun start(min: Int) {
        getSharedPreferences("g", 0).edit()
            .putLong("end", System.currentTimeMillis() + min * 60000L).putInt("total", min * 60).apply()
        render()
    }
    private fun render() {
        if (isLocked(this)) {
            if (sig != "L") buildLock()
            updateLock()
        } else {
            if (lastKey != "") { lastKey = ""; curKind = -1; buzz(); say("সময় শেষ। আপনি পেরেছেন!", true) }
            val s = "S${accOn()}${adminOn()}"
            if (s != sig) { sig = s; buildSetup() }
        }
    }
    private fun buildLock() {
        sig = "L"
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION") root.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        root.removeAllViews()
        val total = getSharedPreferences("g", 0).getInt("total", 600)
        timerTv = tv("", 40f); titleTv = tv("", 24f, Color.parseColor("#38BDF8"))
        stepTv = tv("", 14f, Color.GRAY); textTv = tv("", 19f, Color.WHITE)
        orb = OrbView(this)
        pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = total }
        root.addView(timerTv); root.addView(pb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 24))
        root.addView(orb); root.addView(titleTv); root.addView(stepTv); root.addView(textTv)
    }
    private fun updateLock() {
        val left = ((end(this) - System.currentTimeMillis()) / 1000).toInt()
        val total = getSharedPreferences("g", 0).getInt("total", 600)
        val el = (total - left).coerceAtLeast(0)
        val ps = phases(total)
        val pi = ps.indexOfFirst { el >= it.from && el < it.to }.let { if (it < 0) ps.size - 1 else it }
        val ph = ps[pi]
        val ci = ((el - ph.from) * ph.lines.size / (ph.to - ph.from)).coerceIn(0, ph.lines.size - 1)
        timerTv?.text = "%02d:%02d".format(left / 60, left % 60)
        pb?.progress = el
        orb?.kind = ph.kind; curKind = ph.kind
        titleTv?.text = ph.title; stepTv?.text = "ধাপ ${pi + 1} / ${ps.size}"; textTv?.text = ph.lines[ci]
        val key = "$pi:$ci"
        if (key != lastKey) {
            val newPhase = !lastKey.startsWith("$pi:")
            lastKey = key
            if (newPhase) buzz()
            say((if (newPhase) ph.title + "। " else "") + ph.lines[ci], true)
        }
    }
    private fun buildSetup() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION") root.systemUiVisibility = 0
        root.removeAllViews()
        root.addView(tv("Urge Guard", 28f))
        if (!accOn()) {
            root.addView(tv("ধাপ ১: Accessibility চালু করুন", 16f, Color.YELLOW))
            root.addView(btn("Accessibility Settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        }
        if (!adminOn()) {
            root.addView(tv("ধাপ ২: Device Admin চালু করুন", 16f, Color.YELLOW))
            root.addView(btn("Device Admin চালু") {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java)))
            })
        }
        if (accOn() && adminOn()) {
            root.addView(tv("ইচ্ছা হলে বাটন চাপুন। টাইমার শেষ না হওয়া পর্যন্ত সব লক থাকবে।", 16f, Color.LTGRAY))
            root.addView(btn("৫ মিনিট লক") { start(5) })
            root.addView(btn("১০ মিনিট লক") { start(10) })
            root.addView(btn("১৫ মিনিট লক") { start(15) })
        }
    }
}
