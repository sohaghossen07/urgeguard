package com.urge.guard
import android.app.admin.DeviceAdminReceiver
class AdminReceiver : DeviceAdminReceiver()
